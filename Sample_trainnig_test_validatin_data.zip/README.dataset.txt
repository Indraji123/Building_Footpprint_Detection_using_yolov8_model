# small_grid_1 > 2024-11-25 12:01pm
https://universe.roboflow.com/ksdqm/small_grid_1

Provided by a Roboflow user
License: CC BY 4.0

